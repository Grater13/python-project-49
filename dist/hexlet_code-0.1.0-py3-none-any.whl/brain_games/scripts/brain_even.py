from brain_games.games.even import brain_even


def main():
    brain_even()
