from brain_games.games import progression


def main():
    progression.start()


if __name__ == '__main__':
    main()
