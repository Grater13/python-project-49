from brain_games.games.gcd import brain_gcd


def main():
    brain_gcd()
