from brain_games.games.calc import brain_calc


def main():
    brain_calc()
