from brain_games.games import calc


def main():
    calc.start()


if __name__ == '__main__':
    main()
