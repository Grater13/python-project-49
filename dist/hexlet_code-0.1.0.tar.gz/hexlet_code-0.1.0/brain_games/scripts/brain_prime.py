from brain_games.games.prime import brain_prime

def main():
    brain_prime()
