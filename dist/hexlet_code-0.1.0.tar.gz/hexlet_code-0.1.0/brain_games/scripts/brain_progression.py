from brain_games.games.progression import brain_progression


def main():
    brain_progression()
