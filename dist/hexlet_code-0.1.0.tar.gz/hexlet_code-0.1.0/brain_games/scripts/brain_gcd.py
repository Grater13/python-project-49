from brain_games.games import gcd_game


def main():
    gcd_game.start()


if __name__ == '__main__':
    main()
