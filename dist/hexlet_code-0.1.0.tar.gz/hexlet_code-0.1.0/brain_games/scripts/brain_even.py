from brain_games.games import even


def main():
    even.start()


if __name__ == '__main__':
    main()
