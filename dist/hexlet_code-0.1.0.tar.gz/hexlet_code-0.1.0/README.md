### Hexlet tests and linter status:
[![Actions Status](https://github.com/Grater13/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Grater13/python-project-49/actions)

<a href="https://codeclimate.com/github/Grater13/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fa007622942f108085ce/maintainability" /></a>

How to install the games - python3 -m pip install brain-games

Игра: "Проверка на четность"
Игроку показывается случайное число, и ему нужно ответь "yes", если число чётное, или "no" - если нечётное.
Для победы в игре требуется ввести три правильных ответа
<a href="https://asciinema.org/a/iN5StSjar4Ku0EX8RIxpfaRKy" target="_blank"><img src="https://asciinema.org/a/iN5StSjar4Ku0EX8RIxpfaRKy.svg" /></a>

Игра: "Калькулятор"
Игроку показываеся случайное математичкское выражение, ему нужно вычислить его и записать правильный ответ.
Для победы в игре требуется ввести три правильных ответа
<a href="https://asciinema.org/a/IBSc294rJyBonRBneNBa2WZtL" target="_blank"><img src="https://asciinema.org/a/IBSc294rJyBonRBneNBa2WZtL.svg" /></a>

Игра: "НОД"
Игроку показывается два случайных числа, ему нужно вычислить и ввести наибольший общий делитель этих чисел.
Для победы в игре требуется ввести три правильных ответа
<a href="https://asciinema.org/a/HJYayzcChTwk4rhpQ9WCi5XJK" target="_blank"><img src="https://asciinema.org/a/HJYayzcChTwk4rhpQ9WCi5XJK.svg" /></a>

Игра: "Арифмеическая прогрессия"
Игроку показывается набор чисел, образующих арифметическую прогрессию со скрытым одним числом.
Игрок должен определить это число и ввести ответ.
Для победы в игре требуется ввести три правильных ответа
<a href="https://asciinema.org/a/hMeF2xbRd8EUQBMtaFJ6FEqIE" target="_blank"><img src="https://asciinema.org/a/hMeF2xbRd8EUQBMtaFJ6FEqIE.svg" /></a>

Игра: "Простое ли число"
Игроку показывается случайное число, и ему нужно ответить "yes", если число простое, в ином случае - "no".
Для победы в игре требуется ввести три правильных ответа
<a href="https://asciinema.org/a/wwhFa27YJuUPVfgsbCzDGieSB" target="_blank"><img src="https://asciinema.org/a/wwhFa27YJuUPVfgsbCzDGieSB.svg" /></a>
