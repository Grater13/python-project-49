### Hexlet tests and linter status:
[![Actions Status](https://github.com/Grater13/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Grater13/python-project-49/actions)

<a href="https://codeclimate.com/github/Grater13/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fa007622942f108085ce/maintainability" /></a>

<a href="https://asciinema.org/a/iN5StSjar4Ku0EX8RIxpfaRKy" target="_blank"><img src="https://asciinema.org/a/iN5StSjar4Ku0EX8RIxpfaRKy.svg" /></a>

<a href="https://asciinema.org/a/IBSc294rJyBonRBneNBa2WZtL" target="_blank"><img src="https://asciinema.org/a/IBSc294rJyBonRBneNBa2WZtL.svg" /></a>

<a href="https://asciinema.org/a/HJYayzcChTwk4rhpQ9WCi5XJK" target="_blank"><img src="https://asciinema.org/a/HJYayzcChTwk4rhpQ9WCi5XJK.svg" /></a>

<a href="https://asciinema.org/a/hMeF2xbRd8EUQBMtaFJ6FEqIE" target="_blank"><img src="https://asciinema.org/a/hMeF2xbRd8EUQBMtaFJ6FEqIE.svg" /></a>

<a href="https://asciinema.org/a/wwhFa27YJuUPVfgsbCzDGieSB" target="_blank"><img src="https://asciinema.org/a/wwhFa27YJuUPVfgsbCzDGieSB.svg" /></a>
